'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"version.json": "2b521e10dfa0f067561de489a19d6620",
"favicon.ico": "a506539c834a4f29a378dbd435d4ea6a",
"index.html": "9847c6a1165106a505be4e3c2a347e15",
"/": "9847c6a1165106a505be4e3c2a347e15",
"main.dart.js": "cf38c634aca22ac7a08c339704b31a37",
"flutter.js": "6fef97aeca90b426343ba6c5c9dc5d4a",
"icons/Icon-192.png": "7fc4fc45f49d3647de689a27ae208b85",
"icons/Icon-maskable-192.png": "7fc4fc45f49d3647de689a27ae208b85",
"icons/Icon-maskable-512.png": "b235fdf0c54ecc389d09e21ab31a03be",
"icons/Icon-512.png": "b235fdf0c54ecc389d09e21ab31a03be",
"manifest.json": "a00cc5954467b6b1de5f3f424c77df64",
"assets/AssetManifest.json": "63fa4da63aaa267de4ca604daf1af305",
"assets/NOTICES": "de3a7501592025bef27a23ca1a2649d5",
"assets/FontManifest.json": "d8e80befc17fac48cc6be55103246b5b",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "57d849d738900cfd590e9adc7e208250",
"assets/packages/wakelock_plus/assets/no_sleep.js": "7748a45cd593f33280669b29c2c8919a",
"assets/packages/localization/test/assets/lang2/en_US.json": "b389499c34b7ee2ec98c62fe49e08fa0",
"assets/packages/localization/test/assets/lang2/pt_BR.json": "08e9b784a138126822761beec7614524",
"assets/packages/localization/test/assets/lang/en_US.json": "18804652fbce3b62aacb6cce6f572f3c",
"assets/packages/localization/test/assets/lang/pt_BR.json": "f999b93065fe17d355d1ac5dcc1ff830",
"assets/shaders/ink_sparkle.frag": "f8b80e740d33eb157090be4e995febdf",
"assets/AssetManifest.bin": "275ef23a62b0d58d15e45589074e1b28",
"assets/fonts/Pretendard-Regular.otf": "97b362437880d5cbb01b9305136909ac",
"assets/fonts/Pretendard-Medium.otf": "d88ea6aec529d8945a09a582be9200a2",
"assets/fonts/Pretendard-Bold.otf": "f3189877761796153110738ae129c8a2",
"assets/fonts/MaterialIcons-Regular.otf": "5878047fd34b71b7e85e716ff515748b",
"assets/fonts/NEXON-Bold.ttf": "a09b981735a2d78182f6baaaa0babb5a",
"assets/assets/video/inpleroutine-main-video.mp4": "a8a1f50509dd6453db22e35eaa577ae3",
"assets/assets/images/logo_primary.webp": "d303f28a4e81087e71e0a58a612e8f32",
"assets/assets/images/logo_white.webp": "6b9da3c47d29f618d4af8bb2ba0cce69",
"assets/assets/images/img_no_menu.png": "e233081682447fa63233b9500557a48c",
"assets/assets/images/gitlab_image.png": "9c41426cb517e66843e9948e149184d3",
"assets/assets/images/img_login.webp": "5715dfc9d9f573b3dd78591f2002e491",
"assets/assets/icons/search.svg": "1fc7087dd8f52c8492e2583147bf28b6",
"assets/assets/icons/side_bar/ic-all-schedule.svg": "4e37205e1b466fd34e5d50c250eb3f9b",
"assets/assets/icons/side_bar/ic-go-work.svg": "a39d2f96849eb2851383f9f9c3bc1d21",
"assets/assets/icons/side_bar/ic-home-work.svg": "52da85e535d365eb22d9eff2b84d7bae",
"assets/assets/icons/side_bar/ic-tardy.svg": "c54db80c6a586882a5322faf2425dcdd",
"assets/assets/icons/side_bar/ic-status-management.svg": "45b47fef075a2e39a22d39f46d175180",
"assets/assets/icons/list.svg": "68b869f6ec4c2793303ef12641d582ba",
"assets/assets/icons/right_icon.svg": "3cd34752163855b363dab61cefc3b95b",
"assets/assets/icons/prescription.svg": "21dd6879df196364438b56fb421a6932",
"assets/assets/icons/waiting_38px.svg": "a4051ac33d9a72afee697d5592602304",
"assets/assets/icons/diet_prescription.svg": "57cfaffb332d3c08153104eb9ac6be4b",
"assets/assets/icons/close_1.svg": "bbf27ac29566b24488988838bc659304",
"assets/assets/icons/left_icon.svg": "1c137640117d342ce973cc0626f28391",
"assets/assets/icons/drop_down.svg": "f233629c42a2ec6bb78ef9f87daaf863",
"assets/assets/icons/private_38px.svg": "bacf0e1ae8b0dcc69fa030adae9f3d4f",
"assets/assets/icons/arrow.svg": "55cb9210b5fb347dc6e9dd51f4b31d20",
"assets/assets/icons/reading%2520glasses.svg": "1fc7087dd8f52c8492e2583147bf28b6",
"assets/assets/icons/success_38px.svg": "d1a469cb3db4166a19c13044cb1ae5e1",
"assets/assets/icons/alert.svg": "85b8a75bad0543d1a7d52d3c39c1c08d",
"assets/assets/icons/logout.svg": "b275ac3444ed64bef88aa3200ba35471",
"assets/assets/icons/gra-get-off-work.png": "91f187193c737add7c68ce95316c5029",
"assets/assets/icons/down.svg": "00f22778d798ff82e3b7ddd004014f8f",
"assets/assets/icons/success_38.svg": "3e9f39a508ff6b59f87a86fbbe2ea166",
"assets/assets/icons/delete_line_x_1.svg": "d28553272b8e4b169267c4d0553c7401",
"assets/assets/icons/final_38px.svg": "3e9f39a508ff6b59f87a86fbbe2ea166",
"assets/assets/icons/ic-home-work.svg": "4e7bc3c86f718d6a48f0a44f2e518623",
"assets/assets/icons/food.jpeg": "dede50a559edc6adb3c68caca4d01ed3",
"assets/assets/icons/creating_38px.svg": "863709d7897f148f748d59ea7bd80c31",
"assets/assets/icons/delete_line_x_2.svg": "869559f9cd67ada8361c5651cf3884c9",
"assets/assets/icons/ic-save.svg": "80b4ae9b93193279afb476de3539863d",
"assets/assets/icons/replacement.svg": "c40e2c614ac8aa726f1292101c8d91e9",
"assets/assets/icons/date_range_24px.svg": "18fa14d704d58b43a7d1a72a2b0a57ca",
"assets/assets/icons/gra-go-to-work.png": "c129b7a27364a0607b78284e6d5b9d18",
"assets/assets/icons/refresh_24px.svg": "1599fe52de0cb2228d3530f16a3e8c09",
"assets/assets/icons/refresh_38_px.svg": "c88055caec855ef6d0cd0eeb755ded62",
"assets/assets/icons/ic-close.svg": "fe9679d58a972745eccee26129787def",
"assets/assets/icons/dashboard.svg": "0e768624ebb18e7584769a280f7e0e29",
"assets/assets/icons/my_info.svg": "5d15a45f8a29e258a11c0ea679c5dabd",
"assets/assets/icons/plus.svg": "2f8b55efa013367717d44bed36d62c02",
"assets/assets/icons/info.svg": "6b08f8fccb9825d44eabc7533571e056",
"assets/assets/icons/open_38px.svg": "9e57c162e69ca5102ae811f76b9bc323",
"assets/assets/icons/ic-all-time.svg": "1a10f2bfb7efa31e3fc7d3b3d3cb5b58",
"assets/assets/icons/ic-mail.svg": "a914c319c401ea0cd354a393c126dca5",
"assets/assets/icons/logo.png": "1e5fe97e827fdbfd5675b5f9506d901a",
"assets/assets/icons/ai.svg": "ed1224549a3189862d6238f3808a903c",
"assets/assets/icons/diet_review.svg": "d28ce06fe8ee8405ea48b1ce3c9cfd1c",
"assets/assets/icons/edit.svg": "21bb24997d6e46b619870bf288216b22",
"assets/assets/icons/check_box_empty.svg": "a037b1605b16e652f5dfdd528d609b4d",
"assets/assets/icons/open.svg": "f74638aae977c8f1e77502e6ca4acc33",
"assets/assets/icons/refresh_1.svg": "1661d55e54043fb9162bf52a93a722de",
"assets/assets/icons/ic-work.svg": "fe370147d96c33d88db00769b2226b27",
"assets/assets/icons/img-no-data.png": "05ba4faef5e885212df71ffafbf4ee4e",
"assets/assets/icons/delete.svg": "b3a093b7f3bbddd453ab54d9a87f5107",
"assets/assets/icons/success.svg": "69147b631c488b4f725076786f6c19c6",
"assets/assets/icons/ic-alarm-ring.svg": "b74cb13c708fdae42a836b015ef97689",
"assets/assets/icons/drop_down_right.svg": "f10676c0335d5edf4c226204b2c12e51",
"assets/assets/icons/delete_line_hover.svg": "40d726485b599bd00951dcfc4c5d18b8",
"assets/assets/icons/share.svg": "079bd77e0ec91f7feb521108a7e8a55e",
"assets/assets/icons/top_menu/ic-notification.svg": "9e5121aeb7217108495f8b7bcff78d24",
"assets/assets/icons/top_menu/ic-all-time.svg": "0bd09328dbad0a16ab71bb40f5c1dcfb",
"assets/assets/icons/top_menu/ic-my-info.svg": "a143cce37bfad49d75d473461a009059",
"assets/assets/icons/edit_line_hover.svg": "8ad5f473d98bd97d42eed2f59dca3a26",
"assets/assets/icons/check_box.svg": "d2c5500de316c53366007d9373a4ea77",
"assets/assets/icons/write_38px.svg": "0937cae812a926b2829e8289315ea4ba",
"assets/assets/icons/success_line.svg": "3ce78dfcb7e13f4a4ea2aef880bdf6b3",
"assets/assets/icons/private.svg": "e476f0bab384bf215821287722364d14",
"assets/assets/icons/login/logo-text.svg": "2bb072ef29a06d7353fc7dc55e0c9e99",
"assets/assets/icons/login/logo-image.svg": "defb37057284060b696c8f1bee91b7a1",
"assets/assets/icons/delete_line_x.svg": "9153647d459e604b653701c6577fd32e",
"assets/assets/icons/edit_line.svg": "33270448e0b720df7dcc15098a5b54d8",
"assets/assets/icons/delete_line.svg": "5ea561fed87a2516bad19dcb19a6bc54",
"canvaskit/skwasm.js": "1df4d741f441fa1a4d10530ced463ef8",
"canvaskit/skwasm.wasm": "6711032e17bf49924b2b001cef0d3ea3",
"canvaskit/chromium/canvaskit.js": "8c8392ce4a4364cbb240aa09b5652e05",
"canvaskit/chromium/canvaskit.wasm": "fc18c3010856029414b70cae1afc5cd9",
"canvaskit/canvaskit.js": "76f7d822f42397160c5dfc69cbc9b2de",
"canvaskit/canvaskit.wasm": "f48eaf57cada79163ec6dec7929486ea",
"canvaskit/skwasm.worker.js": "19659053a277272607529ef87acf9d8a"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"assets/AssetManifest.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
